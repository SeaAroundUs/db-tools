from .depth import Filter as depth
from .fao import Filter as fao
from .habitat import Filter as habitat
from .latitude import Filter as latitude
from .polygon import Filter as polygon
from .submergence import Filter as submergence
