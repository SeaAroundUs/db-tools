class ExistingRecordException(Exception): pass

class InvalidTaxonException(Exception): pass

class NoPolygonException(Exception): pass
